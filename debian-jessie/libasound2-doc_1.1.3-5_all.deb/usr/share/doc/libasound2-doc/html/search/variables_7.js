var searchData=
[
  ['handle',['handle',['../structsnd__ctl__ext.html#af014c69147bee94eaddca82d6916326f',1,'snd_ctl_ext']]],
  ['hdr',['hdr',['../structsnd__tplg__tlv__dbscale__template.html#a1ffcf8621a8e6cc663f42355f619be1c',1,'snd_tplg_tlv_dbscale_template::hdr()'],['../structsnd__tplg__mixer__template.html#a47753d107c983bcaa5f45d7b3394acf3',1,'snd_tplg_mixer_template::hdr()'],['../structsnd__tplg__enum__template.html#a480256cd2b82f47087f109bd8e939a76',1,'snd_tplg_enum_template::hdr()'],['../structsnd__tplg__bytes__template.html#a3550150a1ee6e26abeab4bc0da5d0da1',1,'snd_tplg_bytes_template::hdr()']]],
  ['hw_5fconfig',['hw_config',['../structsnd__tplg__link__template.html#a0c8c9d7a828ab74e896ffcdd8d4b1dc3',1,'snd_tplg_link_template']]],
  ['hw_5ffree',['hw_free',['../structsnd__pcm__extplug__callback.html#ad24a08d2400288d5e708a6886b8be50f',1,'snd_pcm_extplug_callback::hw_free()'],['../structsnd__pcm__ioplug__callback.html#a574be37b1eeed5f39806c2386a02a63f',1,'snd_pcm_ioplug_callback::hw_free()']]],
  ['hw_5fparams',['hw_params',['../structsnd__pcm__extplug__callback.html#a7215432f6873a74e5f24da0817a3bbae',1,'snd_pcm_extplug_callback::hw_params()'],['../structsnd__pcm__ioplug__callback.html#a411078734ab59626c15d459800998e3d',1,'snd_pcm_ioplug_callback::hw_params()']]],
  ['hw_5fptr',['hw_ptr',['../structsnd__pcm__ioplug.html#aa314200db67b8cc9ad89cd53f6102f26',1,'snd_pcm_ioplug']]]
];
