var searchData=
[
  ['alsa_20topology_20interface',['ALSA Topology Interface',['../group__topology.html',1,'']]],
  ['alsa_20use_20case_20interface',['ALSA Use Case Interface',['../group__ucm.html',1,'']]]
];
