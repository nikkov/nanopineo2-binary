var searchData=
[
  ['runtime_20arguments_20in_20configuration_20files',['Runtime arguments in configuration files',['../confarg.html',1,'']]],
  ['runtime_20functions_20in_20configuration_20files',['Runtime functions in configuration files',['../conffunc.html',1,'']]],
  ['rawmidi_20interface',['RawMidi interface',['../rawmidi.html',1,'']]]
];
