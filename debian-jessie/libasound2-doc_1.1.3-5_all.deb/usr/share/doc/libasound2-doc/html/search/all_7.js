var searchData=
[
  ['get',['get',['../structsnd__tplg__io__ops__template.html#a954cfcdc65427888bdfa54b6ada8fc50',1,'snd_tplg_io_ops_template']]],
  ['get_5fattribute',['get_attribute',['../structsnd__ctl__ext__callback.html#a9e9b8e2c2527c23130c92a3f2b5aa616',1,'snd_ctl_ext_callback']]],
  ['get_5fchmap',['get_chmap',['../structsnd__pcm__extplug__callback.html#a874d6cd1e6b03186ba5a5f67f3cb8035',1,'snd_pcm_extplug_callback::get_chmap()'],['../structsnd__pcm__ioplug__callback.html#ac2ec050cc6077a5974d43dc20bc4a252',1,'snd_pcm_ioplug_callback::get_chmap()']]],
  ['get_5fenumerated_5finfo',['get_enumerated_info',['../structsnd__ctl__ext__callback.html#a4c1395e41c0da1740226eacd658f5262',1,'snd_ctl_ext_callback']]],
  ['get_5fenumerated_5fname',['get_enumerated_name',['../structsnd__ctl__ext__callback.html#abd68965e4723e436d140561fdeff280d',1,'snd_ctl_ext_callback']]],
  ['get_5finteger64_5finfo',['get_integer64_info',['../structsnd__ctl__ext__callback.html#a12774a89d9d66b1fec865dddf5dbfd13',1,'snd_ctl_ext_callback']]],
  ['get_5finteger_5finfo',['get_integer_info',['../structsnd__ctl__ext__callback.html#af71b075cd0326c4998d1708b25f7ab0f',1,'snd_ctl_ext_callback']]],
  ['global_20defines_20and_20functions',['Global defines and functions',['../group___global.html',1,'']]],
  ['global_2eh',['global.h',['../global_8h.html',1,'']]],
  ['graph',['graph',['../structsnd__tplg__obj__template__t.html#a72cda3f3084484e460f87f2be50ce965',1,'snd_tplg_obj_template_t']]]
];
