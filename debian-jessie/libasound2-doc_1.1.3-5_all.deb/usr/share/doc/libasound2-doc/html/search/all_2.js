var searchData=
[
  ['base',['base',['../structsnd__seq__queue__skew__t.html#a02ab20f62ad37915be1dd929254d9b3b',1,'snd_seq_queue_skew_t::base()'],['../structsnd__tplg__bytes__template.html#a1644bf685a8915059c39b70a21673ad0',1,'snd_tplg_bytes_template::base()']]],
  ['buffer_5fbytes',['buffer_bytes',['../structsnd__tplg__stream__template.html#acc03d35ac9685afcdf44a4d1332d5284',1,'snd_tplg_stream_template']]],
  ['buffer_5fsize',['buffer_size',['../structsnd__pcm__ioplug.html#a6138fb3dabf4c87a321c3e894021ff16',1,'snd_pcm_ioplug']]],
  ['buffer_5fsize_5fmax',['buffer_size_max',['../structsnd__tplg__stream__caps__template.html#a33a0505b7215aac418e034a2017516e0',1,'snd_tplg_stream_caps_template']]],
  ['buffer_5fsize_5fmin',['buffer_size_min',['../structsnd__tplg__stream__caps__template.html#aee27e0c3f72a2758cdb05cd496938d8f',1,'snd_tplg_stream_caps_template']]],
  ['bug_20list',['Bug List',['../bug.html',1,'']]],
  ['bytes_5fctl',['bytes_ctl',['../structsnd__tplg__obj__template__t.html#a327919369281666f2aac412b78cb4a14',1,'snd_tplg_obj_template_t']]]
];
