var searchData=
[
  ['query_5fchmaps',['query_chmaps',['../structsnd__pcm__extplug__callback.html#a9da94c36eff7423b5832b334fd548ce0',1,'snd_pcm_extplug_callback::query_chmaps()'],['../structsnd__pcm__ioplug__callback.html#a7118127cfe9d4c24b63cb1952c62ca91',1,'snd_pcm_ioplug_callback::query_chmaps()']]],
  ['queue',['queue',['../structsnd__seq__ev__queue__control__t.html#a14b3611c58090f9e65b7505c5d69afa9',1,'snd_seq_ev_queue_control_t::queue()'],['../structsnd__seq__event__t.html#a3357b5c3701e93e62eff0bb43f10b6e0',1,'snd_seq_event_t::queue()'],['../structsnd__seq__event__t.html#aa16cf5889566a658ec1ab2389513b4ff',1,'snd_seq_event_t::queue()']]]
];
