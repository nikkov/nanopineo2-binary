var searchData=
[
  ['unused',['unused',['../structsnd__seq__ev__ctrl__t.html#a00d5c02a2da001b1d1101d7e310e7c6b',1,'snd_seq_ev_ctrl_t::unused()'],['../structsnd__seq__ev__queue__control__t.html#a60640082c691368f21db12c11ef62aea',1,'snd_seq_ev_queue_control_t::unused()']]],
  ['update',['update',['../structsnd__pcm__scope__ops__t.html#a9844f4406091bfdd318fd7b5870c6108',1,'snd_pcm_scope_ops_t']]]
];
