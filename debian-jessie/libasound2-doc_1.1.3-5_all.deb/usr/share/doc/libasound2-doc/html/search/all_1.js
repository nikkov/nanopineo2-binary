var searchData=
[
  ['abstract',['abstract',['../structsnd__mixer__selem__regopt.html#a62d43bde34692931ead4ad14b5ad9821',1,'snd_mixer_selem_regopt']]],
  ['access',['access',['../structsnd__pcm__ioplug.html#ac49bda6dd5d2e530d50478be89365ddc',1,'snd_pcm_ioplug::access()'],['../structsnd__tplg__ctl__template.html#a0a3e7fa10db19ea81524fe6a55f92e94',1,'snd_tplg_ctl_template::access()']]],
  ['addr',['addr',['../structsnd__pcm__channel__area__t.html#a83acdf3245dcb74dffe74cce53d65876',1,'snd_pcm_channel_area_t::addr()'],['../structsnd__seq__event__t.html#a3a2df2fd3def9f0443bd4759b3cf4077',1,'snd_seq_event_t::addr()']]],
  ['alsa_5fconfig_5fpath_5fdefault',['ALSA_CONFIG_PATH_DEFAULT',['../conf_8c.html#aa7ae5d3b32a1ec3a9aa0456a5a2f9091',1,'conf.c']]],
  ['alsa_5fconfig_5fpath_5fvar',['ALSA_CONFIG_PATH_VAR',['../conf_8c.html#a8b857484628b5b4cbd2ac60503d4f80e',1,'conf.c']]],
  ['appl_5fptr',['appl_ptr',['../structsnd__pcm__ioplug.html#a66cf297ebbce9453b4bbd961f081c730',1,'snd_pcm_ioplug']]],
  ['asoundef_2eh',['asoundef.h',['../asoundef_8h.html',1,'']]],
  ['asoundlib_2eh',['asoundlib.h',['../asoundlib_8h.html',1,'']]],
  ['async_2ec',['async.c',['../async_8c.html',1,'']]],
  ['access_20mask_20functions',['Access Mask Functions',['../group___p_c_m___access.html',1,'']]],
  ['alsa_20topology_20interface',['ALSA Topology Interface',['../group__topology.html',1,'']]],
  ['alsa_20use_20case_20interface',['ALSA Use Case Interface',['../group__ucm.html',1,'']]]
];
