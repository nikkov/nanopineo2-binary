var searchData=
[
  ['name',['name',['../structsnd__devname.html#a662af64d66720b53c3bfbcbf9f49ac1e',1,'snd_devname::name()'],['../structsnd__pcm__extplug.html#a01ae590e2eb20d8054e29e4300a82706',1,'snd_pcm_extplug::name()'],['../structsnd__pcm__ioplug.html#a26cb709f26f0a27b431c4f8ac8a8432e',1,'snd_pcm_ioplug::name()'],['../structsnd__ctl__ext.html#a186de36995e8f5d879fcf3abea5aeff2',1,'snd_ctl_ext::name()'],['../structsnd__tplg__ctl__template.html#ac22769fc8e2dee6739f6b0d0617b939c',1,'snd_tplg_ctl_template::name()'],['../structsnd__tplg__widget__template.html#abeb31c5543b70053912437c03d7de386',1,'snd_tplg_widget_template::name()'],['../structsnd__tplg__stream__template.html#a8c683c2bfc0f6f81a13e9b17c8032905',1,'snd_tplg_stream_template::name()'],['../structsnd__tplg__stream__caps__template.html#ae54c502a3da78e5fb6cd9c865b0c9bbb',1,'snd_tplg_stream_caps_template::name()'],['../structsnd__tplg__link__template.html#a10d5beb2799114b6fe8b837c242faeb1',1,'snd_tplg_link_template::name()']]],
  ['namehint_2ec',['namehint.c',['../namehint_8c.html',1,'']]],
  ['names_2ec',['names.c',['../names_8c.html',1,'']]],
  ['next',['next',['../structsnd__devname.html#a5544e716ce4155fee42b262ccf15c245',1,'snd_devname']]],
  ['nonblock',['nonblock',['../structsnd__pcm__ioplug.html#a5186222a90004912d0895ba47631423d',1,'snd_pcm_ioplug::nonblock()'],['../structsnd__ctl__ext.html#a3688ec45a9f38ba73c1ae9058414b033',1,'snd_ctl_ext::nonblock()']]],
  ['note',['note',['../structsnd__seq__ev__note__t.html#a97803cf476f3a352463daf483caa3db1',1,'snd_seq_ev_note_t::note()'],['../structsnd__seq__event__t.html#a71ca4f3c6683c7cbc9a5ff82937da3b4',1,'snd_seq_event_t::note()']]],
  ['num_5fchannels',['num_channels',['../structsnd__tplg__channel__map__template.html#a02ac7ec7cf8cded80d70ceb15806f3aa',1,'snd_tplg_channel_map_template']]],
  ['num_5fctls',['num_ctls',['../structsnd__tplg__widget__template.html#a8410052e0b03c98fffb3d308243879b4',1,'snd_tplg_widget_template']]],
  ['num_5fregs',['num_regs',['../structsnd__tplg__bytes__template.html#ad46cbdd6e9a9f5dd2f1b840de64dc26a',1,'snd_tplg_bytes_template']]],
  ['num_5fstreams',['num_streams',['../structsnd__tplg__pcm__template.html#a6230c8e843c6778a1ebc3e5af5aac21e',1,'snd_tplg_pcm_template::num_streams()'],['../structsnd__tplg__link__template.html#a6c4c04ed502e0bfe550d1bf78f2d8bf2',1,'snd_tplg_link_template::num_streams()']]]
];
