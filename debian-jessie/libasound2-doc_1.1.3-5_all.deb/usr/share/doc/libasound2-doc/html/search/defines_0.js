var searchData=
[
  ['alsa_5fconfig_5fpath_5fdefault',['ALSA_CONFIG_PATH_DEFAULT',['../conf_8c.html#aa7ae5d3b32a1ec3a9aa0456a5a2f9091',1,'conf.c']]],
  ['alsa_5fconfig_5fpath_5fvar',['ALSA_CONFIG_PATH_VAR',['../conf_8c.html#a8b857484628b5b4cbd2ac60503d4f80e',1,'conf.c']]]
];
