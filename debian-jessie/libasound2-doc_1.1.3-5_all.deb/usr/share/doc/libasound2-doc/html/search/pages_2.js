var searchData=
[
  ['configuration_20files',['Configuration files',['../conf.html',1,'']]],
  ['control_20interface',['Control interface',['../control.html',1,'']]]
];
