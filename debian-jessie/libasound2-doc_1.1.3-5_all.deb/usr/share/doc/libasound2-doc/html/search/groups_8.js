var searchData=
[
  ['midi_20commands',['MIDI Commands',['../group___m_i_d_i___commands.html',1,'']]],
  ['midi_20controllers',['MIDI Controllers',['../group___m_i_d_i___controllers.html',1,'']]],
  ['mixer_20interface',['Mixer Interface',['../group___mixer.html',1,'']]],
  ['midi_20sequencer',['MIDI Sequencer',['../group___sequencer.html',1,'']]]
];
