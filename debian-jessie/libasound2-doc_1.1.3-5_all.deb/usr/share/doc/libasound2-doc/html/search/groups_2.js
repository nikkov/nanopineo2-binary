var searchData=
[
  ['deprecated_20functions',['Deprecated Functions',['../group___p_c_m___deprecated.html',1,'']]],
  ['description_20functions',['Description Functions',['../group___p_c_m___description.html',1,'']]],
  ['direct_20access_20_28mmap_29_20functions',['Direct Access (MMAP) Functions',['../group___p_c_m___direct.html',1,'']]],
  ['debug_20functions',['Debug Functions',['../group___p_c_m___dump.html',1,'']]]
];
