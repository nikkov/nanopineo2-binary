var searchData=
[
  ['external_20control_20plugin_20sdk',['External Control Plugin SDK',['../ctl_external_plugins.html',1,'']]]
];
