var searchData=
[
  ['hooks_20in_20configuration_20files',['Hooks in configuration files',['../confhooks.html',1,'']]],
  ['high_20level_20control_20interface',['High level control interface',['../hcontrol.html',1,'']]]
];
