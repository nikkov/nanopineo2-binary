var searchData=
[
  ['tag',['tag',['../structsnd__seq__event__t.html#a6027db669ee78712c1924754a10817d1',1,'snd_seq_event_t']]],
  ['texts',['texts',['../structsnd__tplg__enum__template.html#a2b04f038f41433f492427b5008228271',1,'snd_tplg_enum_template']]],
  ['tick',['tick',['../unionsnd__seq__timestamp__t.html#a0eeb11cee9e96defdd4a6d35640aa6e3',1,'snd_seq_timestamp_t']]],
  ['ticks',['ticks',['../structsnd__timer__read__t.html#a6f1deb447c21188ac4590e872358edd9',1,'snd_timer_read_t']]],
  ['time',['time',['../unionsnd__seq__timestamp__t.html#a013e05e7f01cac7bc23d96f39e233cd0',1,'snd_seq_timestamp_t::time()'],['../structsnd__seq__ev__queue__control__t.html#a0bb1053e4dfddaa448be19674c8d26dc',1,'snd_seq_ev_queue_control_t::time()'],['../structsnd__seq__event__t.html#a455b8a2995b2978db1b3b862ad7b5b34',1,'snd_seq_event_t::time()']]],
  ['timer_20interface',['Timer Interface',['../group___timer.html',1,'(Global Namespace)'],['../timer.html',1,'(Global Namespace)']]],
  ['timer_2ec',['timer.c',['../timer_8c.html',1,'']]],
  ['timer_2eh',['timer.h',['../timer_8h.html',1,'']]],
  ['timer_5fquery_2ec',['timer_query.c',['../timer__query_8c.html',1,'']]],
  ['tlv',['tlv',['../structsnd__ctl__ext.html#abf57ae6adacfa8d8a49791c5ca47ebd3',1,'snd_ctl_ext::tlv()'],['../structsnd__tplg__ctl__template.html#ac99aa1726d01df67900f6f264a55c8f6',1,'snd_tplg_ctl_template::tlv()']]],
  ['tlv_2ec',['tlv.c',['../tlv_8c.html',1,'']]],
  ['topology_20interface',['Topology Interface',['../group__topology.html',1,'']]],
  ['transfer',['transfer',['../structsnd__pcm__extplug__callback.html#a5c1c8cb34f5c1df7af6141362f473091',1,'snd_pcm_extplug_callback::transfer()'],['../structsnd__pcm__ioplug__callback.html#a3a9578f0e8f2de4203e988c3a5a205fb',1,'snd_pcm_ioplug_callback::transfer()']]],
  ['tstamp',['tstamp',['../structsnd__timer__tread__t.html#a18a654c60721911059e616c5573df91b',1,'snd_timer_tread_t']]],
  ['tv_5fnsec',['tv_nsec',['../structsnd__seq__real__time__t.html#a79e39ed4061a4fa572275954d253a4bd',1,'snd_seq_real_time_t']]],
  ['tv_5fsec',['tv_sec',['../structsnd__seq__real__time__t.html#aeeb195e734102b35594128bb28e9c7d7',1,'snd_seq_real_time_t']]],
  ['type',['type',['../structsnd__pcm__chmap__query__t.html#a42a40687d56ed049fe37a574d1de0979',1,'snd_pcm_chmap_query_t::type()'],['../structsnd__seq__event__t.html#ab4076699c7f089b0d44c626a69311b04',1,'snd_seq_event_t::type()'],['../structsnd__tplg__tlv__template.html#ae387167827b44dd3e98db6910d1f667e',1,'snd_tplg_tlv_template::type()'],['../structsnd__tplg__ctl__template.html#ab67cddcd99af948e7f1c31e88fae277b',1,'snd_tplg_ctl_template::type()'],['../structsnd__tplg__obj__template__t.html#a5ac8a01fbb895f368c4bacb574def128',1,'snd_tplg_obj_template_t::type()']]]
];
