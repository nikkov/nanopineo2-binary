var searchData=
[
  ['mixer_20interface',['Mixer interface',['../mixer.html',1,'']]]
];
